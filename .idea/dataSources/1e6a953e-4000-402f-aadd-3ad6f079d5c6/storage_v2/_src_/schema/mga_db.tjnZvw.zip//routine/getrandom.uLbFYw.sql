create procedure getrandom(OUT randomNumber int)
BEGIN
  SELECT floor(rand()*100000000) INTO randomNumber;
end;

