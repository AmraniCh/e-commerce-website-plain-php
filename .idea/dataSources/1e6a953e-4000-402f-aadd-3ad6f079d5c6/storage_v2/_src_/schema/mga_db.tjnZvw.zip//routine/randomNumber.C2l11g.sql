create function randomNumber() returns int(50)
RETURN floor(rand()*1000000);

