create trigger randomNumber
  before INSERT
  on client
  for each row
  set new.codeEmail=randomNumber();

